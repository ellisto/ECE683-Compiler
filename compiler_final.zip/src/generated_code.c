#include "code_defs.h"
#include "std_defs.h"
#include "runtime.h"
int main(){
goto L1;
L0: R[1] = R[1] + 1; //allocate space for varresult
R[1] = R[1] + 1; //allocate space for varoutString
goto L3;
L2: R[1] = R[1] + 1; //allocate space for arg ctl
R[1] = R[1] + 1; //allocate space for arg label
R[1] = R[1] + 1; //allocate space for vari
R[1] = R[1] + 10; // allocate space for array someArray
R[3] = MM[R[0] + 2];//factor ctl
R[4] = R[3] == 0; //case
R[4] = !R[4]; //case
if(R[4]) goto L5; //case
R[5] = R[0];
R[6] = &&L0; //store id we're looking for
L6: R[7] = MM[R[5]];
R[7] = (R[7] == R[6]); //see if we're there yet
if(R[7]) goto L7; // if so, then done
R[5] = MM[R[5]-1]; // go back to next FP
goto L6;
L7: R[6] = MM[R[0] + 3];//factor label
MM[R[5] + 3] = R[6]; //assignment_statement outString
R[5] = R[0];
R[6] = &&L0; //store id we're looking for
L8: R[7] = MM[R[5]];
R[7] = (R[7] == R[6]); //see if we're there yet
if(R[7]) goto L9; // if so, then done
R[5] = MM[R[5]-1]; // go back to next FP
goto L8;
L9: R[7] = R[0];
R[8] = &&L0; //store id we're looking for
L11: R[9] = MM[R[7]];
R[9] = (R[9] == R[8]); //see if we're there yet
if(R[9]) goto L12; // if so, then done
R[7] = MM[R[7]-1]; // go back to next FP
goto L11;
L12: R[7] = MM[R[7] + 3]; // offset from correct FP
MM[R[1]] = R[0]; //store old frame ptr
R[1] = R[1] + 1; //incrementing frm ptr storage 
R[0] = R[1]; //set frame ptr to top of stk
MM[R[0]] = &&PUTSTRING; //store addrs as func id
MM[R[0] + 1] = &&L10;
R[1] = R[1] + 2; //leave room for return value and address
MM[R[0] + 2] = R[7]; //passing argument 
goto PUTSTRING;
L10: R[6] = MM[R[0]]; //store return val
R[1] = R[0];
R[0] = MM[R[0]-1];
MM[R[5] + 2] = R[6]; //assignment_statement result
R[6] = 0; //factor 0
MM[R[0]] = R[6]; //assignment_statement dowork
goto L4;
L5:R[4] = R[3] == 1; //case
R[4] = !R[4]; //case
if(R[4]) goto L13; //case
R[5] = R[0];
R[6] = &&L0; //store id we're looking for
L14: R[7] = MM[R[5]];
R[7] = (R[7] == R[6]); //see if we're there yet
if(R[7]) goto L15; // if so, then done
R[5] = MM[R[5]-1]; // go back to next FP
goto L14;
L15: R[6] = MM[R[0] + 3];//factor label
MM[R[5] + 3] = R[6]; //assignment_statement outString
R[5] = R[0];
R[6] = &&L0; //store id we're looking for
L16: R[7] = MM[R[5]];
R[7] = (R[7] == R[6]); //see if we're there yet
if(R[7]) goto L17; // if so, then done
R[5] = MM[R[5]-1]; // go back to next FP
goto L16;
L17: R[7] = R[0];
R[8] = &&L0; //store id we're looking for
L19: R[9] = MM[R[7]];
R[9] = (R[9] == R[8]); //see if we're there yet
if(R[9]) goto L20; // if so, then done
R[7] = MM[R[7]-1]; // go back to next FP
goto L19;
L20: R[7] = MM[R[7] + 3]; // offset from correct FP
MM[R[1]] = R[0]; //store old frame ptr
R[1] = R[1] + 1; //incrementing frm ptr storage 
R[0] = R[1]; //set frame ptr to top of stk
MM[R[0]] = &&PUTSTRING; //store addrs as func id
MM[R[0] + 1] = &&L18;
R[1] = R[1] + 2; //leave room for return value and address
MM[R[0] + 2] = R[7]; //passing argument 
goto PUTSTRING;
L18: R[6] = MM[R[0]]; //store return val
R[1] = R[0];
R[0] = MM[R[0]-1];
MM[R[5] + 2] = R[6]; //assignment_statement result
R[7] = 0; //factor 0
MM[9999] = 'D';
MM[9998] = 'o';
MM[9997] = 'i';
MM[9996] = 'n';
MM[9995] = 'g';
MM[9994] = ' ';
MM[9993] = 'w';
MM[9992] = 'o';
MM[9991] = 'r';
MM[9990] = 'k';
MM[9989] = ' ';
MM[9988] = 'f';
MM[9987] = 'o';
MM[9986] = 'r';
MM[9985] = ' ';
MM[9984] = 'c';
MM[9983] = 'a';
MM[9982] = 's';
MM[9981] = 'e';
MM[9980] = ' ';
MM[9979] = '1';
MM[9978] = '\0';
R[8] = 9999; // string factor "Doing work for case 1"
MM[R[1]] = R[0]; //store old frame ptr
R[1] = R[1] + 1; //incrementing frm ptr storage 
R[0] = R[1]; //set frame ptr to top of stk
MM[R[0]] = &&L2; //store addrs as func id
MM[R[0] + 1] = &&L21;
R[1] = R[1] + 2; //leave room for return value and address
MM[R[0] + 2] = R[7]; //passing argument ctl
MM[R[0] + 3] = R[8]; //passing argument label
goto L2;
L21: R[6] = MM[R[0]]; //store return val
R[1] = R[0];
R[0] = MM[R[0]-1];
MM[R[0]] = R[6]; //assignment_statement dowork
goto L4;
L13:R[4] = R[3] == 2; //case
R[4] = !R[4]; //case
if(R[4]) goto L22; //case
R[5] = R[0];
R[6] = &&L0; //store id we're looking for
L23: R[7] = MM[R[5]];
R[7] = (R[7] == R[6]); //see if we're there yet
if(R[7]) goto L24; // if so, then done
R[5] = MM[R[5]-1]; // go back to next FP
goto L23;
L24: R[6] = MM[R[0] + 3];//factor label
MM[R[5] + 3] = R[6]; //assignment_statement outString
R[5] = R[0];
R[6] = &&L0; //store id we're looking for
L25: R[7] = MM[R[5]];
R[7] = (R[7] == R[6]); //see if we're there yet
if(R[7]) goto L26; // if so, then done
R[5] = MM[R[5]-1]; // go back to next FP
goto L25;
L26: R[7] = R[0];
R[8] = &&L0; //store id we're looking for
L28: R[9] = MM[R[7]];
R[9] = (R[9] == R[8]); //see if we're there yet
if(R[9]) goto L29; // if so, then done
R[7] = MM[R[7]-1]; // go back to next FP
goto L28;
L29: R[7] = MM[R[7] + 3]; // offset from correct FP
MM[R[1]] = R[0]; //store old frame ptr
R[1] = R[1] + 1; //incrementing frm ptr storage 
R[0] = R[1]; //set frame ptr to top of stk
MM[R[0]] = &&PUTSTRING; //store addrs as func id
MM[R[0] + 1] = &&L27;
R[1] = R[1] + 2; //leave room for return value and address
MM[R[0] + 2] = R[7]; //passing argument 
goto PUTSTRING;
L27: R[6] = MM[R[0]]; //store return val
R[1] = R[0];
R[0] = MM[R[0]-1];
MM[R[5] + 2] = R[6]; //assignment_statement result
R[7] = 1; //factor 1
MM[9977] = 'D';
MM[9976] = 'o';
MM[9975] = 'i';
MM[9974] = 'n';
MM[9973] = 'g';
MM[9972] = ' ';
MM[9971] = 'w';
MM[9970] = 'o';
MM[9969] = 'r';
MM[9968] = 'k';
MM[9967] = ' ';
MM[9966] = 'f';
MM[9965] = 'o';
MM[9964] = 'r';
MM[9963] = ' ';
MM[9962] = 'c';
MM[9961] = 'a';
MM[9960] = 's';
MM[9959] = 'e';
MM[9958] = ' ';
MM[9957] = '2';
MM[9956] = '\0';
R[8] = 9977; // string factor "Doing work for case 2"
MM[R[1]] = R[0]; //store old frame ptr
R[1] = R[1] + 1; //incrementing frm ptr storage 
R[0] = R[1]; //set frame ptr to top of stk
MM[R[0]] = &&L2; //store addrs as func id
MM[R[0] + 1] = &&L30;
R[1] = R[1] + 2; //leave room for return value and address
MM[R[0] + 2] = R[7]; //passing argument ctl
MM[R[0] + 3] = R[8]; //passing argument label
goto L2;
L30: R[6] = MM[R[0]]; //store return val
R[1] = R[0];
R[0] = MM[R[0]-1];
MM[R[0]] = R[6]; //assignment_statement dowork
goto L4;
L22:R[5] = R[0];
R[6] = &&L0; //store id we're looking for
L31: R[7] = MM[R[5]];
R[7] = (R[7] == R[6]); //see if we're there yet
if(R[7]) goto L32; // if so, then done
R[5] = MM[R[5]-1]; // go back to next FP
goto L31;
L32: R[6] = MM[R[0] + 3];//factor label
MM[R[5] + 3] = R[6]; //assignment_statement outString
R[5] = R[0];
R[6] = &&L0; //store id we're looking for
L33: R[7] = MM[R[5]];
R[7] = (R[7] == R[6]); //see if we're there yet
if(R[7]) goto L34; // if so, then done
R[5] = MM[R[5]-1]; // go back to next FP
goto L33;
L34: R[7] = R[0];
R[8] = &&L0; //store id we're looking for
L36: R[9] = MM[R[7]];
R[9] = (R[9] == R[8]); //see if we're there yet
if(R[9]) goto L37; // if so, then done
R[7] = MM[R[7]-1]; // go back to next FP
goto L36;
L37: R[7] = MM[R[7] + 3]; // offset from correct FP
MM[R[1]] = R[0]; //store old frame ptr
R[1] = R[1] + 1; //incrementing frm ptr storage 
R[0] = R[1]; //set frame ptr to top of stk
MM[R[0]] = &&PUTSTRING; //store addrs as func id
MM[R[0] + 1] = &&L35;
R[1] = R[1] + 2; //leave room for return value and address
MM[R[0] + 2] = R[7]; //passing argument 
goto PUTSTRING;
L35: R[6] = MM[R[0]]; //store return val
R[1] = R[0];
R[0] = MM[R[0]-1];
MM[R[5] + 2] = R[6]; //assignment_statement result
R[7] = 2; //factor 2
MM[9955] = 'D';
MM[9954] = 'o';
MM[9953] = 'i';
MM[9952] = 'n';
MM[9951] = 'g';
MM[9950] = ' ';
MM[9949] = 'w';
MM[9948] = 'o';
MM[9947] = 'r';
MM[9946] = 'k';
MM[9945] = ' ';
MM[9944] = 'f';
MM[9943] = 'o';
MM[9942] = 'r';
MM[9941] = ' ';
MM[9940] = 'd';
MM[9939] = 'e';
MM[9938] = 'f';
MM[9937] = 'a';
MM[9936] = 'u';
MM[9935] = 'l';
MM[9934] = 't';
MM[9933] = ' ';
MM[9932] = 'c';
MM[9931] = 'a';
MM[9930] = 's';
MM[9929] = 'e';
MM[9928] = '\0';
R[8] = 9955; // string factor "Doing work for default case"
MM[R[1]] = R[0]; //store old frame ptr
R[1] = R[1] + 1; //incrementing frm ptr storage 
R[0] = R[1]; //set frame ptr to top of stk
MM[R[0]] = &&L2; //store addrs as func id
MM[R[0] + 1] = &&L38;
R[1] = R[1] + 2; //leave room for return value and address
MM[R[0] + 2] = R[7]; //passing argument ctl
MM[R[0] + 3] = R[8]; //passing argument label
goto L2;
L38: R[6] = MM[R[0]]; //store return val
R[1] = R[0];
R[0] = MM[R[0]-1];
MM[R[0]] = R[6]; //assignment_statement dowork
L4:R[6] = 4; //factor 4
MM[R[0]] = R[6]; //assignment_statement dowork
R[2] = MM[R[0]+1];
goto *R[2]; //write return statement
L3: MM[9927] = 'A';
MM[9926] = ' ';
MM[9925] = 't';
MM[9924] = 'e';
MM[9923] = 's';
MM[9922] = 't';
MM[9921] = ' ';
MM[9920] = 'j';
MM[9919] = 'o';
MM[9918] = 'b';
MM[9917] = '\0';
R[6] = 9927; // string factor "A test job"
MM[R[0] + 3] = R[6]; //assignment_statement outString
R[7] = MM[R[0] + 3];//factor outString
MM[R[1]] = R[0]; //store old frame ptr
R[1] = R[1] + 1; //incrementing frm ptr storage 
R[0] = R[1]; //set frame ptr to top of stk
MM[R[0]] = &&PUTSTRING; //store addrs as func id
MM[R[0] + 1] = &&L39;
R[1] = R[1] + 2; //leave room for return value and address
MM[R[0] + 2] = R[7]; //passing argument 
goto PUTSTRING;
L39: R[6] = MM[R[0]]; //store return val
R[1] = R[0];
R[0] = MM[R[0]-1];
MM[R[0] + 2] = R[6]; //assignment_statement result
R[7] = 1; //factor 1
MM[9916] = 'F';
MM[9915] = 'i';
MM[9914] = 'r';
MM[9913] = 's';
MM[9912] = 't';
MM[9911] = ' ';
MM[9910] = 'S';
MM[9909] = 't';
MM[9908] = 'r';
MM[9907] = 'i';
MM[9906] = 'n';
MM[9905] = 'g';
MM[9904] = '\0';
R[8] = 9916; // string factor "First String"
MM[R[1]] = R[0]; //store old frame ptr
R[1] = R[1] + 1; //incrementing frm ptr storage 
R[0] = R[1]; //set frame ptr to top of stk
MM[R[0]] = &&L2; //store addrs as func id
MM[R[0] + 1] = &&L40;
R[1] = R[1] + 2; //leave room for return value and address
MM[R[0] + 2] = R[7]; //passing argument ctl
MM[R[0] + 3] = R[8]; //passing argument label
goto L2;
L40: R[6] = MM[R[0]]; //store return val
R[1] = R[0];
R[0] = MM[R[0]-1];
MM[R[0] + 2] = R[6]; //assignment_statement result
R[7] = MM[R[0] + 3];//factor outString
MM[R[1]] = R[0]; //store old frame ptr
R[1] = R[1] + 1; //incrementing frm ptr storage 
R[0] = R[1]; //set frame ptr to top of stk
MM[R[0]] = &&PUTSTRING; //store addrs as func id
MM[R[0] + 1] = &&L41;
R[1] = R[1] + 2; //leave room for return value and address
MM[R[0] + 2] = R[7]; //passing argument 
goto PUTSTRING;
L41: R[6] = MM[R[0]]; //store return val
R[1] = R[0];
R[0] = MM[R[0]-1];
MM[R[0] + 2] = R[6]; //assignment_statement result
R[7] = 5; //factor 5
MM[9903] = 'S';
MM[9902] = 'e';
MM[9901] = 'c';
MM[9900] = 'o';
MM[9899] = 'n';
MM[9898] = 'd';
MM[9897] = ' ';
MM[9896] = 'S';
MM[9895] = 't';
MM[9894] = 'r';
MM[9893] = 'i';
MM[9892] = 'n';
MM[9891] = 'g';
MM[9890] = '\0';
R[8] = 9903; // string factor "Second String"
MM[R[1]] = R[0]; //store old frame ptr
R[1] = R[1] + 1; //incrementing frm ptr storage 
R[0] = R[1]; //set frame ptr to top of stk
MM[R[0]] = &&L2; //store addrs as func id
MM[R[0] + 1] = &&L42;
R[1] = R[1] + 2; //leave room for return value and address
MM[R[0] + 2] = R[7]; //passing argument ctl
MM[R[0] + 3] = R[8]; //passing argument label
goto L2;
L42: R[6] = MM[R[0]]; //store return val
R[1] = R[0];
R[0] = MM[R[0]-1];
MM[R[0] + 2] = R[6]; //assignment_statement result
R[7] = MM[R[0] + 3];//factor outString
MM[R[1]] = R[0]; //store old frame ptr
R[1] = R[1] + 1; //incrementing frm ptr storage 
R[0] = R[1]; //set frame ptr to top of stk
MM[R[0]] = &&PUTSTRING; //store addrs as func id
MM[R[0] + 1] = &&L43;
R[1] = R[1] + 2; //leave room for return value and address
MM[R[0] + 2] = R[7]; //passing argument 
goto PUTSTRING;
L43: R[6] = MM[R[0]]; //store return val
R[1] = R[0];
R[0] = MM[R[0]-1];
MM[R[0] + 2] = R[6]; //assignment_statement result
R[2] = MM[R[0]+1];
goto *R[2]; //write return statement
L1: R[0] = 0;
R[1] = R[0];
MM[R[0]] = &&L0;
MM[R[0]+1] = &&end;
R[1] = R[1]+2;
goto L0;
GETBOOL: MM[R[0]] = getBool();
R[2] = MM[R[0]+1];
goto *R[2]; //write return statement
GETINT: MM[R[0]] = getInt();
R[2] = MM[R[0]+1];
goto *R[2]; //write return statement
GETSTRING: MM[R[0]] = getString();
R[2] = MM[R[0]+1];
goto *R[2]; //write return statement
PUTBOOL: MM[R[0]] = putBool(MM[R[0] + 2]);
R[2] = MM[R[0]+1];
goto *R[2]; //write return statement
PUTINT: MM[R[0]] = putInt(MM[R[0] + 2]);
R[2] = MM[R[0]+1];
goto *R[2]; //write return statement
PUTSTRING: MM[R[0]] = putString(MM[R[0] + 2]);
R[2] = MM[R[0]+1];
goto *R[2]; //write return statement
SQRT: MM[R[0]] = isqrt(MM[R[0] + 2]);
R[2] = MM[R[0]+1];
goto *R[2]; //write return statement
INT2BOOL: MM[R[0]] = int2bool(MM[R[0] + 2]);
R[2] = MM[R[0]+1];
goto *R[2]; //write return statement
BOOL2INT: MM[R[0]] = bool2int(MM[R[0] + 2]);
R[2] = MM[R[0]+1];
goto *R[2]; //write return statement
end:  return 0;
 }
