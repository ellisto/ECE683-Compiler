#include "code_defs.h"
#include "std_defs.h"
#include <stdio.h>
int main(){
int i;
goto MAIN;
L0: MM[R[0]] = R[1]; // store return address
R[1] = R[0] + 1; //set R[1] to point to top of stack
R[1] = R[1]+1; //allocate space for var
R[1] = R[1]+1; //allocate space for var
R[1] = R[1]+1; //allocate space for var
R[1] = R[1]+1; //allocate space for var
R[2] = 2;//factor
MM[R[0]+1] = R[2]; //assignment_statement
R[2] = 5;//factor
MM[R[0]+2] = R[2]; //assignment_statement
R[2] = 1;//factor
MM[R[0]+3] = R[2]; //assignment_statement
R[2] = MM[R[0] + 3];//factor
R[3] = MM[R[0] + 1];//factor
R[4] = MM[R[0] + 1];//factor
R[5] = MM[R[0] + 1];//factor
R[6] = MM[R[0] + 1];//factor
R[7] = MM[R[0] + 2];//factor
R[5] = R[5] == R[6]; //rel2
R[6] = R[6] < R[7]; //rel2
R[4] = R[4] == R[5]; //rel2
R[5] = R[5]&& R[6]; //rel2
R[3] = R[3] == R[4]; //rel2
R[4] = R[4]&& R[5]; //rel2
R[2] = R[2] < R[3]; //rel2
R[3] = R[3]&& R[4]; //rel2
R[2] = R[2]&& R[3]; //relation 
MM[R[0]+4] = R[2]; //assignment_statement
R[2] = MM[R[0] + 4];//factor
MM[R[0]+1] = R[2]; //assignment_statement
R[1] = MM[R[0]];
goto *R[1]; //write return statement
MAIN: R[0] = 0;
R[1] = &&end;
call1: goto L0;
end: for(i = 0; i < MAX_USED_REGISTER; i++)
printf("R[%d] = %d\n",i,R[i]);
 return 0;
 }
