#include "symboltableentry.h"

symboltableentry::symboltableentry(token t){
  this->t = new token(t);
  type = new int(-1);
  arraybool = new bool(false);
  arraysize = new int(-1);
  functionbool = new bool(false);
  paramlist = new vector<int>();
  //  this->token_type = tt;
}

symboltableentry::~symboltableentry(){
  /*  delete t;
  delete type;
  delete arraybool;
  delete arraysize;
  delete functionbool;
  delete paramlist;*/
}

void symboltableentry::set_type(int type){
  *(this->type) = type;
}
void symboltableentry::set_array(int arraysize){
  *(this->arraybool) = true;
  *(this->arraysize) = arraysize;
}
void symboltableentry::set_function(vector<int> param_list){
  *(this->functionbool) = true;
  *(this->paramlist) = param_list;
}

bool symboltableentry::is_array(){
  return *arraybool;
}
bool symboltableentry::is_function(){
  return *functionbool;
}
int symboltableentry::get_arraysize(){
  if(*arraybool){
    return *arraysize;
  }else
    return -1;
}
vector<int>* symboltableentry::get_paramlist(){
  if(*functionbool)
    return paramlist;
  else
    return NULL;
}

token * symboltableentry::get_token() const{
  return t;
}

int symboltableentry::get_type(){
  return *type;
}

bool operator<(const symboltableentry& t1, const symboltableentry& t2){
  return *(t1.t) < *(t2.t);
}

bool operator==(const symboltableentry& t1, const symboltableentry& t2){
  //  return *(t1.t) == *(t2.t);
  return t1.get_token()->get_value() == t2.get_token()->get_value();
}

ostream& operator<<(ostream& o, const symboltableentry& s){
  o << *(s.t)
    << ", type: " << *(s.type)
    << ", array? " << *(s.arraybool)
    << ", arraysize: " << *(s.arraysize)
    << ", function? " << *(s.functionbool)
    << ", paramlist: " << s.paramlist;
  
  return o;
}
