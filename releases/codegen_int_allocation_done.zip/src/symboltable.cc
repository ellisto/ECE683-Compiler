#include "symboltable.h"

symboltable::symboltable(){
  table = unordered_set<symboltableentry>();
  prev = NULL;

  //void scanner::initST(){
  
  add(token(FUNCTION,string("function")));
  add(token(BEGIN,string("begin")));
  add(token(END,string("end")));
  add(token(TYPE,string("integer")));
  add(token(TYPE,string("boolean")));
  add(token(TYPE,string("string")));
  add(token(IF,string("if")));
  add(token(THEN,string("then")));
  add(token(ELSE,string("else")));
  add(token(WHILE,string("while")));
  add(token(CASE,string("case")));
  add(token(IS,string("is")));
  add(token(WHEN,string("when")));
  add(token(DEFAULT,string("default")));
  add(token(AND,string("and")));
  add(token(OR,string("or")));
  add(token(NOT,string("not")));
  
  token* t = add(token(ID, "getBool"));
  set_tokentype(*t,BOOLEANTYPE);
  set_function(*t,vector<int>());


  t = add(token(ID, "getInt"));
  set_tokentype(*t,INTEGERTYPE);
  set_function(*t,vector<int>());

  t = add(token(ID, "getString"));
  set_tokentype(*t,STRINGTYPE);
  set_function(*t,vector<int>());

  t = add(token(ID, "putBool"));
  set_tokentype(*t,INTEGERTYPE);
  set_function(*t,vector<int>(1,BOOLEANTYPE));

  t = add(token(ID, "putInt"));
  set_tokentype(*t,INTEGERTYPE);
  set_function(*t,vector<int>(1,INTEGERTYPE));

  t = add(token(ID, "putString"));
  set_tokentype(*t,INTEGERTYPE);
  set_function(*t,vector<int>(1,STRINGTYPE));

  t = add(token(ID, "sqrt"));
  set_tokentype(*t,INTEGERTYPE);
  set_function(*t,vector<int>(1,INTEGERTYPE));

  t = add(token(ID, "int2bool"));
  set_tokentype(*t,BOOLEANTYPE);
  set_function(*t,vector<int>(1,INTEGERTYPE));

  t = add(token(ID, "bool2int"));
  set_tokentype(*t,INTEGERTYPE);
  set_function(*t,vector<int>(1,BOOLEANTYPE));

  /*  boolean getBool()

     integer getInt()

     string getString()

     integer putBool(boolean)

     integer putInt(integer)

     integer putString(string)

     integer sqrt(integer)

 boolean int2bool(integer)

 integer bool2int(boolean)*/
}

symboltable::~symboltable(){
  
}

token * symboltable::add(token t){
  //  cout << this << " adding token " << t << endl;
  
  pair<unordered_set<symboltableentry>::iterator,bool> ret;
  ret = table.insert(symboltableentry(t));
  unordered_set<symboltableentry>::iterator retit = ret.first;
  return (*retit).get_token();
}

symboltableentry *symboltable::find_entry(token t){
  unordered_set<symboltableentry>::iterator it;
  symboltableentry * ret = NULL;
  it = table.find(t);
  if(it == table.end()){//if it's not found in this st, go back a level.
    //cout << "here" << endl;
    if(prev)
      ret = prev->find_entry(t);
  }else{
    //    ret = const_cast<symboltableentry*>( &(*it) );
    ret = new symboltableentry(*it);
  }
  if(!ret)
    //cout << "returning null" << endl;
  //cout << this << " returning pointer to" << *ret << endl;
  return ret;
}
token * symboltable::find(token t){
  symboltableentry * entry = find_entry(t);
  token * ret = NULL;
  if(entry)
    ret = entry->get_token();
  return ret;
}

void symboltable::set_prev(symboltable* prev_st){
  this->prev = prev_st;
  return;
}

void symboltable::set_tokentype(token t, int tokentype){
  symboltableentry entry = *find_entry(t);
  entry.set_type(tokentype);
}

int symboltable::get_tokentype(token t){
  symboltableentry entry = *find_entry(t);
  int type = entry.get_token()->get_type();
  int ret =-1;

  if(type == ID){
    ret = entry.get_type();
  }
  else if(type == NUMBER){
    ret = INTEGERTYPE;
  }else if(type == STRING){
    ret = STRINGTYPE;
  }
  
  return ret;
}

void symboltable::set_arraysize(token t, int size){
  symboltableentry entry = *find_entry(t);
  entry.set_array(size);
}

bool symboltable::is_array(token t){
  symboltableentry entry = *find_entry(t);
  return entry.is_array();
}

int symboltable::get_arraysize(token t){
  symboltableentry entry = *find_entry(t);
  return entry.get_arraysize();
}

void symboltable::set_function(token t, vector<int> plist){
  symboltableentry entry = *find_entry(t);
  entry.set_function(plist);
  //  cout << "set function " << *find_entry(t) << endl;
}

void symboltable::set_function(token t, vector<int> plist, map<int,pair<int,int> > arrayparams){
  symboltableentry entry = *find_entry(t);
  entry.set_function(plist,arrayparams);
}

bool symboltable::is_function(token t){
  return find_entry(t)->is_function();
}

vector<int>* symboltable::get_parameterlist(token t){
  return find_entry(t)->get_paramlist();
}

map<int, pair<int,int> >* symboltable::get_arrayparams(token t){
  return find_entry(t)->get_arrayparams();
}

void symboltable::set_label(token t,string lbl){
  symboltableentry entry = *find_entry(t);
  entry.set_label(lbl);
}

string symboltable::get_label(token t){
  symboltableentry entry = *find_entry(t);
  return entry.get_label();
}

symboltable * symboltable::get_prev(){
  return prev;
}

/*
void symboltable::set_memloc(token t, int ml){
  symboltableentry entry = *find_entry(t);
  entry.set_memloc(ml);
}
int  symboltable::get_memloc(token t){
  symboltableentry entry = *find_entry(t);
  return entry.get_memloc();
}
*/

void symboltable::increment_ardepth(token t){
  symboltableentry entry = *find_entry(t);
  entry.increment_ardepth();
}
int symboltable::get_ardepth(token t){
  symboltableentry entry = *find_entry(t);
  return entry.get_ardepth();
}

void symboltable::set_offset(token t,int os){
  symboltableentry entry = *find_entry(t);
  entry.set_offset(os);
}
int symboltable::get_offset(token t){
  symboltableentry entry = *find_entry(t);
  return entry.get_offset();
  }

token symboltable::get_ftoken(){
  return *ftoken;
}
void symboltable::set_ftoken(token t){
  ftoken = new token(t);
}

ostream& operator<<(ostream& out, const symboltable& st){
  out << "st at " << &st << endl;
  for(unordered_set<symboltableentry>::const_iterator it = st.table.begin(); it != st.table.end(); it++){
    cout << *it << endl;
  }
  return out;
}
