#include "symboltable.h"

symboltable::symboltable(){
  table = set<token>();
  types = map<token*,int>();
  arraysizes = map<token*,int>();
  prev = NULL;
}

token * symboltable::add(token t){
  //  cout << "adding token " << t << endl;

  pair<set<token>::iterator,bool> ret;
  ret = table.insert(t);
  set<token>::iterator retit = ret.first;
  return const_cast<token *>(&*retit);
}

token * symboltable::find(token t){
  //return const_cast<token *> (&(*table.find(t)));
  set<token>::iterator it;
  token * ret = NULL;

  it = table.find(t);
  if(it == table.end()){//if it's not found in this st, go back a level.
    if(prev!= NULL)
      ret = prev->find(t);
  }else{
    ret = const_cast<token*> (&(*it));
  }

  return ret;
}

void symboltable::set_prev(symboltable* prev_st){
  this->prev = prev_st;
  return;
}

void symboltable::set_tokentype(token t, int tokentype){
  token * tptr = this->find(t);

   if(types.count(tptr)==0)
     types[tptr] = tokentype;
}

int symboltable::get_tokentype(token t){
  token * tptr = this->find(t);
  //  int ret = (*(this->types.find(tptr))).second;
  int type = t.get_type();
  int ret =-1;

  if(type == ID){
    if(types.count(tptr)!=0)
      ret = types[tptr];
    else
      ret = prev->get_tokentype(t);
  }
  else if(type == NUMBER){
    ret = INTEGERTYPE;
  }else if(type == STRING){
    ret = STRINGTYPE;
  }
  
  return ret;
}


void symboltable::set_arraysize(token t, int size){
  cout << "set arraysize"<< endl;
  token * tptr = this->find(t);
  if(arraysizes.count(tptr)==0){
    cout << "setting arraysizes[" << tptr << "] = " << size << endl;
    arraysizes[tptr] = size;
  }
  cout << "end set arraysize"<< endl;
}


bool symboltable::is_array(token t){
  cout << "is array" << endl;
  token * tptr = this->find(t);
  
  if(arraysizes.count(tptr)!=0)
    return true;
  else{
    if(prev == NULL){
      return false;
    }else{
      return prev->is_array(t);
    }
  } 
  
}

int symboltable::get_arraysize(token t){
  cout << "get arraysize" << endl;
  token * tptr = this->find(t);
  
  if(is_array(t))
    if(arraysizes.count(tptr)!=0)
      return arraysizes[tptr];
    else 
      return prev->get_arraysize(t);
  else
    return -1;
}

void symboltable::set_function(token t, vector<int> plist){
  token * tptr = this->find(t);
  if(functions.count(tptr)==0){
    vector<int>* pptr =  new vector<int>(plist);
    functions[tptr] = pptr;
    //cout << "added function " << *tptr << " with plist " << pptr << endl;
  }
}

bool symboltable::is_function(token t){
  cout << "is " << t <<" a function? ";
  token * tptr = this->find(t);
  //  cout << (functions.count(tptr)==0) << endl;

  return functions.count(tptr)!=0;
}

vector<int>* symboltable::get_parameterlist(token t){
  token * tptr = this->find(t);
  cout << "returning paramlist for " <<  t << endl;
  if(functions.count(tptr)>0)
    return functions[tptr];
  else if(this->prev == NULL)
    return NULL;
  else
    return prev->get_parameterlist(t);
}


symboltable * symboltable::get_prev(){
  return prev;
}
