#ifndef SYMBOLTABLEENTRY_H
#define SYMBOLTABLEENTRY_H
#include "token.h"

class symboltableentry{
  token* t;
  int token_type; // type information for identifiers or numbers.
 public:
  symboltableentry(token*, int);
};

#endif //SYMBOLTABLEENTRY_H
