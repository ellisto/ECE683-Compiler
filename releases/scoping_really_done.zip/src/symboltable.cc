#include "symboltable.h"

symboltable::symboltable(){
  table = unordered_set<symboltableentry>();
  prev = NULL;

  //void scanner::initST(){
  
  add(token(FUNCTION,string("function")));
  add(token(BEGIN,string("begin")));
  add(token(END,string("end")));
  add(token(TYPE,string("integer")));
  add(token(TYPE,string("boolean")));
  add(token(TYPE,string("string")));
  add(token(IF,string("if")));
  add(token(THEN,string("then")));
  add(token(ELSE,string("else")));
  add(token(WHILE,string("while")));
  add(token(CASE,string("case")));
  add(token(IS,string("is")));
  add(token(WHEN,string("when")));
  add(token(DEFAULT,string("default")));
  add(token(AND,string("and")));
  add(token(OR,string("or")));
  add(token(NOT,string("not")));
  
}

symboltable::~symboltable(){
  
}

token * symboltable::add(token t){
  //  cout << this << " adding token " << t << endl;
  
  pair<unordered_set<symboltableentry>::iterator,bool> ret;
  ret = table.insert(symboltableentry(t));
  unordered_set<symboltableentry>::iterator retit = ret.first;
  return (*retit).get_token();
}

symboltableentry *symboltable::find_entry(token t){
  unordered_set<symboltableentry>::iterator it;
  symboltableentry * ret = NULL;
  it = table.find(t);
  if(it == table.end()){//if it's not found in this st, go back a level.
    //cout << "here" << endl;
    if(prev)
      ret = prev->find_entry(t);
  }else{
    //    ret = const_cast<symboltableentry*>( &(*it) );
    ret = new symboltableentry(*it);
  }
  if(!ret)
    //cout << "returning null" << endl;
  //cout << this << " returning pointer to" << *ret << endl;
  return ret;
}
token * symboltable::find(token t){
  symboltableentry * entry = find_entry(t);
  token * ret = NULL;
  if(entry)
    ret = entry->get_token();
  return ret;
}

void symboltable::set_prev(symboltable* prev_st){
  this->prev = prev_st;
  return;
}

void symboltable::set_tokentype(token t, int tokentype){
  symboltableentry entry = *find_entry(t);
  entry.set_type(tokentype);
}

int symboltable::get_tokentype(token t){
  symboltableentry entry = *find_entry(t);
  int type = entry.get_token()->get_type();
  int ret =-1;

  if(type == ID){
    ret = entry.get_type();
  }
  else if(type == NUMBER){
    ret = INTEGERTYPE;
  }else if(type == STRING){
    ret = STRINGTYPE;
  }
  
  return ret;
}

void symboltable::set_arraysize(token t, int size){
  symboltableentry entry = *find_entry(t);
  entry.set_array(size);
}

bool symboltable::is_array(token t){
  symboltableentry entry = *find_entry(t);
  return entry.is_array();
}

int symboltable::get_arraysize(token t){
  symboltableentry entry = *find_entry(t);
  return entry.get_arraysize();
}

void symboltable::set_function(token t, vector<int> plist){
  symboltableentry entry = *find_entry(t);
  entry.set_function(new vector<int>(plist));
}

bool symboltable::is_function(token t){
  return find_entry(t)->is_function();
}

vector<int>* symboltable::get_parameterlist(token t){
  return find_entry(t)->get_paramlist();
}

symboltable * symboltable::get_prev(){
  return prev;
}

ostream& operator<<(ostream& out, const symboltable& st){
  out << "st at " << &st << endl;
  for(unordered_set<symboltableentry>::const_iterator it = st.table.begin(); it != st.table.end(); it++){
    cout << *it << endl;
  }
  return out;
}
