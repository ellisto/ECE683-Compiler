#include "code_defs.h"
#include "std_defs.h"
int main(){
goto MAIN;
L0: MM[R[0]] = R[1];
R[1] = R[0] + 1;
R[1] = R[1]+1;
R[1] = R[1]+1;
R[1] = R[1]+1;
MM[R[0]+2] = MM[R[0]+0] = R[1] = MM[R[0]];
goto *R[1];
MAIN: R[0] = 0;
R[1] = &&end;
call1: goto L0;
end: return 0;
 }
