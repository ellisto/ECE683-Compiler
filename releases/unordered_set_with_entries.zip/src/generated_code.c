#include "code_defs.h"
#include "std_defs.h"
int main(){
}
