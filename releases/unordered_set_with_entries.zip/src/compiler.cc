#include<iostream>
#include<string>
#include "scanner.h"
#include "token.h"
#include "linecounter.h"
#include "symboltable.h"
#include "parser.h"
#include "code_writer.h"
#include<cstring>
#include<cstdlib>

using namespace std;  

void report_error(string);

//int linenumber = 0;


int main(int argc, char * argv[]){
  if(argc !=2){
    report_error("Usage: scanner filename");
    return 1;
  }
  
  line_counter l;
  symboltable st;
  scanner s(l,st);
  code_writer c("generated_code.c","code_defs.h","std_defs.h");
  
  if(!s.attach_file(argv[1])){
    report_error("Cannot open file for reading!");
    return 1;
  }
  
  parser p(s,l,st,c);
  /*  while(s.good()){
    cout << s.scan() << endl;
    }*/
  
  c.init_generated_code();

  while(s.good()){
    if(!p.parse())
      p.reset_error();
  }
  
  c.init_code_defs();
  c.init_std_defs();
  c.finalize_generated_code();

  system(string("gcc -g " + c.get_gen_filename()).c_str());
  //testing gorram symboltable
  /*
  token t1(7,"end");
  token t2(1,"myfunc");
  st.add(t1);
  st.add(t2);
  st.set_tokentype(t2,STRINGTYPE);
  st.set_function(t2,new vector<int>());
  */
  
  return 0;
}

