#ifndef CODE_WRITER_H
#define CODE_WRITER_H

#include<string>
#include<iostream>
#include<fstream>

using namespace std;

class code_writer{
  ofstream generated_code;
  ofstream code_defs;
  ofstream std_defs;
  int register_num;
  int label_num;
  string gen_file, code_defs_file, std_defs_file;
 public:
  code_writer();
  code_writer(string gen_file,string code_defs_file,string std_defs_file);
  void init_generated_code();
  void finalize_generated_code();
  void init_code_defs();
  void init_std_defs();
  void write_code_defs(string);
  void write_std_defs(string);
  void write_code(string);
  void open_generated_code(string);
  void open_code_defs(string);
  void open_std_defs(string);
  int get_register_num();
  void inc_register_num();
  string get_gen_filename();
  string get_std_defs_filename();
  string get_code_defs_filename();
  string get_next_label();
};

#endif // CODE_WRITER_H
