#include "symboltable.h"

symboltable::symboltable(){
  table = unordered_set<symboltableentry>();
  prev = NULL;
}

token * symboltable::add(token t){
  //  cout << "adding token " << t << endl;

  pair<unordered_set<symboltableentry>::iterator,bool> ret;
  ret = table.insert(symboltableentry(t));
  unordered_set<symboltableentry>::iterator retit = ret.first;
  return (*retit).get_token();
}

symboltableentry *symboltable::find_entry(token t){
  unordered_set<symboltableentry>::iterator it;
  symboltableentry * ret = NULL;
  it = table.find(t);
  if(it == table.end()){//if it's not found in this st, go back a level.
    if(prev)
      ret = prev->find_entry(t);
  }else{
    //    ret = const_cast<symboltableentry*>( &(*it) );
    ret = new symboltableentry(*it);
  }

  return ret;
}
token * symboltable::find(token t){
  symboltableentry * entry = find_entry(t);
  token * ret = NULL;
  if(entry)
    ret = entry->get_token();
  else
  cout << "st returning token: " << *ret <<endl;
  return ret;
}

void symboltable::set_prev(symboltable* prev_st){
  this->prev = prev_st;
  return;
}

void symboltable::set_tokentype(token t, int tokentype){
  symboltableentry entry = *find_entry(t);
  entry.set_type(tokentype);
}

int symboltable::get_tokentype(token t){
  symboltableentry entry = *find_entry(t);
  int type = entry.get_token()->get_type();
  int ret =-1;

  if(type == ID){
    ret = entry.get_type();
  }
  else if(type == NUMBER){
    ret = INTEGERTYPE;
  }else if(type == STRING){
    ret = STRINGTYPE;
  }
  
  return ret;
}

void symboltable::set_arraysize(token t, int size){
  symboltableentry entry = *find_entry(t);
  entry.set_array(size);
}

bool symboltable::is_array(token t){
  symboltableentry entry = *find_entry(t);
  return entry.is_array();
}

int symboltable::get_arraysize(token t){
  symboltableentry entry = *find_entry(t);
  return entry.get_arraysize();
}

void symboltable::set_function(token t, vector<int> plist){
  symboltableentry entry = *find_entry(t);
  entry.set_function(new vector<int>(plist));
}

bool symboltable::is_function(token t){
  return find_entry(t)->is_function();
}

vector<int>* symboltable::get_parameterlist(token t){
  return find_entry(t)->get_paramlist();
}

symboltable * symboltable::get_prev(){
  return prev;
}
