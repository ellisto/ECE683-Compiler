#include "code_writer.h"

code_writer::code_writer(){
  register_num = 0;
}
code_writer::code_writer(string gen_file,string code_defs_file,string std_defs_file){
  this->gen_file = gen_file;
  this->code_defs_file = code_defs_file;
  this->std_defs_file = std_defs_file;
  
  generated_code.open(gen_file.c_str());
  register_num = 0;

  /*code_defs.open(code_defs_file.c_str());
  std_defs.open(std_defs_file.c_str());*/
}
void code_writer::init_code_defs(){
  if(!code_defs.is_open()){
    code_defs.open(code_defs_file.c_str());
  }
  if(code_defs.is_open()){
    code_defs << "#define MAX_USED_REGISTER " << register_num  << endl;
  }
}
void code_writer::init_std_defs(){
  if(!std_defs.is_open()){
    std_defs.open(std_defs_file.c_str());
  }
  if(std_defs.is_open()){
    std_defs << "#include \"" << code_defs_file << "\"" << endl
	     << endl
	     << "int R[MAX_USED_REGISTER];" << endl
	     <<  "int MM[1000];" << endl;
  }
}
void code_writer::init_generated_code(){
 if(!generated_code.is_open()){
    generated_code.open(gen_file.c_str());
  }
  if(generated_code.is_open()){
    generated_code << "#include \"" << code_defs_file << "\"" << endl
		   << "#include \"" << std_defs_file << "\"" << endl
		   << "int main(){" << endl;
  }
}

void code_writer::finalize_generated_code(){
 if(!generated_code.is_open()){
    generated_code.open(gen_file.c_str());
  }
  if(generated_code.is_open()){
    generated_code << "}" << endl;
    generated_code.close();
  }
}

void code_writer::write_code(string line){
 if(generated_code.is_open()){
    generated_code << line << endl;
  }
}
void code_writer::write_code_defs(string line){
  if(!code_defs.is_open()){
    code_defs.open(code_defs_file.c_str());
  }
  if(code_defs.is_open()){
    code_defs << line << endl;
  }
}
void code_writer::write_std_defs(string line){
  if(!std_defs.is_open()){
    std_defs.open(std_defs_file.c_str());
  }
 if(std_defs.is_open()){
    std_defs << line << endl;
  }
}
void code_writer::open_generated_code(string filename){
  generated_code.open(filename.c_str());
}
void code_writer::open_code_defs(string filename){
  code_defs.open(filename.c_str());
}
void code_writer::open_std_defs(string filename){
  std_defs.open(filename.c_str());
}

int code_writer::get_register_num(){
  return register_num;
}
void code_writer::inc_register_num(){
  register_num++;
}

string code_writer::get_gen_filename(){
  return gen_file;
}
string code_writer::get_std_defs_filename(){
  return std_defs_file;
}
string code_writer::get_code_defs_filename(){
  return code_defs_file;
}
