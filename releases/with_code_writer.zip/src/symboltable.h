#ifndef SYMBOLTABLE_H
#define SYMBOLTABLE_H
#include "token.h"
#include "enums.h"
#include<tr1/unordered_set>
#include<map>
#include<set>
#include<vector>

using namespace std::tr1;


class symboltable{
  //  unordered_set<token> table; 
  set<token> table;
  map<token*,int> types; // map of tokens to their types (semantic type, not tokentype)
  map<token*,int> arraysizes;
  map<token*,vector<int>* > functions; // map of function identifiers to their parameter lists.
  symboltable* prev;
 public:
  symboltable();
  token * add(token);
  token * find(token);
  void  set_prev(symboltable* prev_st);
  symboltable * get_prev(); 
  void set_tokentype(token,int);
  int get_tokentype(token);
  void set_function(token, vector<int>);
  bool is_function(token); //returns true if the token is a function, false otherwise.
  vector<int>* get_parameterlist(token); // returns parameter list for function.
  int get_arraysize(token);
  bool is_array(token);
  void set_arraysize(token,int);
};

#endif //SYMBOLTABLE_H
