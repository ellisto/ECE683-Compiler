#include "symboltableentry.h"

symboltableentry::symboltableentry(token* t, int tt){
  this->t = t;
  this->token_type = tt;
}
