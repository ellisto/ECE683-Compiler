#ifndef PARSER_H
#define PARSER_H

#include "scanner.h"
#include "linecounter.h"
#include "symboltable.h"
#include "token.h"
#include <string>

using namespace std;
// before i forget: make functions for each grammar rule, i.e.
// if_statement(){
//   if (token != "if") ERROR
//   scan()
//   expression()
//   ...
class parser{
  scanner * s;
  line_counter * l;
  symboltable * st;
  token * next_token;
  bool error_flag;
  //  int next_type;
 public:
  //constructors
  parser();
  parser(scanner&,line_counter&,symboltable&);

  bool parse();
  
  void attach_scanner(scanner&);

  void scan_next_token();
  void set_next_type();
  bool check_token_type(int type, const char* expected);
  bool check_types(int type1, int type2);
  void panic();

  bool is_error();
  void reset_error();

  void add_scope();
  void remove_scope();

  //grammar rules
  void function_declaration(int);
  token function_header(int);
  void parameter_list(vector<int>*);
  int parameter();
  void function_body(token);
  void declaration();
  void declaration2(int);
  void variable_declaration(int);
  int type_mark();
  void array_size();
  void statement();
  void assignment_statement();
  int destination();
  void if_statement();
  void while_statement();
  void case_statement();
  int identifier();
  int identifier(int);
  int expression();
  int expression2();
  int arithOp();
  int arithOp2();
  int relation();
  int relation2();
  int term();
  int factor();
  void name_or_function_call(token);
  void argument_list(token, int);
  //  void number();
  //void string();

  void debug(const char* m);
  void debug(const char* m,int);
  
};

#endif //PARSER_H
