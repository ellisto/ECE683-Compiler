#include<iostream>
#include<string>
#include "scanner.h"
#include "token.h"
#include "linecounter.h"
#include "symboltable.h"
#include "parser.h"
#include<cstring>

using namespace std;  

void report_error(string);

//int linenumber = 0;


int main(int argc, char * argv[]){
  if(argc !=2){
    report_error("Usage: scanner filename");
    return 1;
  }
  
  line_counter l;
  symboltable st;
  scanner s(l,st);
  
  if(!s.attach_file(argv[1])){
    report_error("Cannot open file for reading!");
    return 1;
  }
  
  parser p(s,l,st);
  /*  while(s.good()){
    cout << s.scan() << endl;
    }*/
  
  while(s.good()){
    if(!p.parse())
      p.reset_error();
  }

  //testing gorram symboltable
  /*
  token t1(7,"end");
  token t2(1,"myfunc");
  st.add(t1);
  st.add(t2);
  st.set_tokentype(t2,STRINGTYPE);
  st.set_function(t2,new vector<int>());
  */
  
  return 0;
}
