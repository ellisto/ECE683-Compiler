#include "parser.h"
#include "report_error.h"
#include <string>
#include <cstdlib>
//#define DEBUG

using namespace std;
void parser::debug(const char* m){
#ifdef DEBUG
  cout << m << " token: " << *next_token << endl;
#endif
}

void parser::debug(const char* m,int i){
#ifdef DEBUG
  cout << m << i << endl;
#endif
}

parser::parser(){
  this->l = new line_counter();
  this->st = new symboltable(); // global scope
  this->s = new scanner(*l,*st);
  error_flag=false;
}

parser::parser(scanner& s,line_counter& l,symboltable& st, code_writer& c){
  this->s = &s;
  this->l = &l;
  this->st = &st;
  this->c = &c;
  error_flag=false;
  this->next_token = new token(this->s->scan());
}

void parser::attach_scanner(scanner&s){
  this->s = &s;
  this->next_token = new token(this->s->scan());
}

void parser::reset_error(){
  error_flag= false;
}

bool parser::parse(){
  int tm;
  tm = type_mark();
  //  cout << "global st: " << st << endl;
  function_declaration(tm);
  return !error_flag;
}

void parser::scan_next_token(){
  if(s->good() && !error_flag){
    *next_token = s->scan();
#ifdef DEBUG
    cout << "Got new token: " << *next_token << endl;
#endif
  }
}

bool parser::check_token_type(int type, const char* expected){
  if(error_flag){return false;}
  if(next_token->get_type() != type){
    char error[255];
    sprintf(error,"Syntax Error! %s expected.",expected);
    report_error(error,l->get_linenumber(),*next_token);
    panic();
    error_flag = true;
    return false;
  }
  return true;
}

bool parser::check_types(int type1, int type2){
  if(type1 == type2){
    return true;
  }else{
    if(type1 >= 0 && type2 >= 0)
      report_error("Type mismatch ", l->get_linenumber());
    return false;
  }
}
bool parser::check_array_sizes(int s1, int s2){
  if(s1 == s2){
    return true;
  }else{
    report_error("Array size mismatch ", l->get_linenumber());
    return false;
  }
}

void parser::panic(){
  if(error_flag)
    reset_error();
  while(next_token->get_type()!=END && next_token->get_type()!= EOFMARKER && next_token->get_type() != SEMICOLON){
#ifdef DEBUG
    cout << "PANIC MODE! Skipping " << *next_token << endl;
#endif
    scan_next_token();
  }
  if(next_token->get_type()==END){
    debug("last token was end, getting a new one.");
    scan_next_token();
  }
  if(next_token->get_type()==EOFMARKER){
    debug("Panicked to end of file.");
    return;
  }
  if(next_token->get_type() == SEMICOLON)
    return;
  scan_next_token();
}

bool parser::is_error(){
  return error_flag;
}

void parser::function_declaration(int typemark){
  //  if(error_flag){error_flag=false;}
  debug("enter function_declaration");
  c->write_code(c->get_next_label() + ": ");
  c->write_code("MM[R[0]] = R[1];"); // store return address
  c->write_code("R[1] = R[0] + 1;"); //set R[1] to point to top of stack
  token ftoken = function_header(typemark);
  //cout << "f_dec ftoken is : " << ftoken << endl;
  add_scope();
  function_body(ftoken);
  
  c->write_code("R[1] = MM[R[0]];");
  c->write_code("goto *R[1];"); //write return statement
  remove_scope();
  if(next_token->get_type() != EOFMARKER){
    reset_error();
  }
  debug("exit function_declaration");
}

token parser::function_header(int typemark){
  if(error_flag){return token();}
  debug("enter function_header");
  check_token_type(FUNCTION,"'function'");
  scan_next_token();
  token ftoken = *next_token;
  //  cout << "candidate function: " << ftoken << endl;
  identifier(typemark);
  vector<int> plist = vector<int>();
  map<int, pair<int,int> > arrayparams = map<int, pair<int,int> >();
  check_token_type(LPAREN,"'('");
  scan_next_token();
  if(next_token->get_type()!=RPAREN){
    parameter_list(&plist,&arrayparams);
  }
  check_token_type(RPAREN,"')'");
  ftoken = *st->add(ftoken); // add to current scope if not already there
  st->set_function(ftoken,plist,arrayparams); // add function and parameterlist to symboltable

  /*vector<int> tmp = *(st->get_parameterlist(ftoken));
  for(vector<int>::const_iterator it = tmp.begin(); it!=tmp.end(); it++){
    cout << *it << endl;
    }*/
  scan_next_token();
  debug("exit function_header");
  return ftoken;
}
void parser::parameter_list(vector<int> * plist, map<int, pair<int,int> > *arrayparams){
  if(error_flag){return;}
  debug("enter parameter_list");
  pair<int,token> param = parameter();
  int ptype = param.first;
  token ptok = param.second;
  if(ptype>=0){
    plist->push_back(ptype);
    if(ptype == ARRAYTYPE){
      int parraysize = st->get_arraysize(ptok);
      int parraytype = st->get_tokentype(ptok);
      /*      cout << "for array parameter " << ptok << ": " << endl
	   << "parraysize: " << parraysize << endl
	   << "parraytype: " << parraytype <<endl;*/
      (*arrayparams)[plist->size()-1] = pair<int,int>(parraytype,parraysize);
    }
  }
  if(next_token->get_type()==COMMA){
    check_token_type(COMMA,"','");
    scan_next_token();
    parameter_list(plist,arrayparams);
  }
  debug("exit parameter_list");
}

pair<int,token> parser::parameter(){
  if(error_flag){return pair<int,token>(-1,token());}
  debug("enter parameter");
  int tm = type_mark();
  token paramname = *next_token;
  variable_declaration(tm);
  if(st->is_array(paramname)){
    tm = ARRAYTYPE;
  }
  debug("exit parameter");
  return pair<int,token>(tm,paramname);
}
void parser::function_body(token ftoken){
  //TODO: Check to ensure there is a return statement.
  if(error_flag){return;}
  debug("enter function_body");
  bool returned = false;
  while(next_token->get_type()!=BEGIN && next_token->get_type() != EOFMARKER ){
    //cout << "next_token->get_type()" << next_token->get_type() << " begin: " << BEGIN << endl;
    declaration();
    check_token_type(SEMICOLON,"';'");
    reset_error();
    scan_next_token();
  }
  check_token_type(BEGIN,"'begin'");
  scan_next_token();
  while(next_token->get_type()!=END && next_token->get_type() != EOFMARKER){
    reset_error();
    //if(*next_token == ftoken){
    //cout << "next token: " << next_token << endl;
    //cout << "ftoken: " << &ftoken << endl;
    if(next_token->get_value() == ftoken.get_value()){
      assignment_statement();
      if(!error_flag){
	returned = true;
	check_token_type(SEMICOLON,"';'");
	scan_next_token();
	break;
      }
    }
    statement();
    check_token_type(SEMICOLON,"';'");
    reset_error();
    scan_next_token();
  }

  check_token_type(END,"'end'");
  scan_next_token();
  check_token_type(FUNCTION,"'function'");
  scan_next_token();
  if(!returned){//error
    string errormsg = string("No return statement for function ").append(string(ftoken.get_value()));
    report_error(errormsg ,l->get_linenumber());
  }
  debug("exit function_body");
}

void parser::declaration(){
  if(error_flag){return;}
  debug("enter declaration");
  int tm = type_mark();
  declaration2(tm);
  debug("exit declaration");
}

void parser::declaration2(int tm){
  if(error_flag){return;}
  debug("enter declaration2");
  if(next_token->get_type()==FUNCTION){
    function_declaration(tm);
  }else{
    variable_declaration(tm);
  }
  debug("exit declaration2");
}

void parser::variable_declaration(int tm){
  if(error_flag){return;}
  debug("enter variable_declaration");
  token varid = *next_token;
  identifier(tm);
  varid = *st->add(varid); // add to current scope if not already there
  if(next_token->get_type() == LBRACKET){
    check_token_type(LBRACKET,"'['");
    scan_next_token();
    check_token_type(NUMBER,"array size");
    int arraysize = atoi((next_token->get_value()).c_str());
    st->set_arraysize(varid,arraysize);
    //cout << "arraysize for " << varid << " is " << st->get_arraysize(varid) << endl;
    scan_next_token();
    check_token_type(RBRACKET,"']'");
    scan_next_token();  
  }
  debug("exit variable_declaration");
}
int parser::type_mark(){
  if(error_flag){return -1;}
  debug("enter type_mark");
  int tm=0;
  check_token_type(TYPE,"type mark");
  
  string val = next_token->get_value();

    switch (val[0]){
  case 'i':
    tm =  INTEGERTYPE;
    break;
  case 'b':
    tm = BOOLEANTYPE;
    break;
  case 's':
    tm = STRINGTYPE;
    break;
    }
  scan_next_token();
  debug("exit type_mark");
  return tm;
  
}

void parser::statement(){
  if(error_flag){return;}
  debug("enter statement");
  switch(next_token->get_type()){
  case IF:
    if_statement();
    break;
  case WHILE:
    while_statement();
    break;
  case CASE:
    case_statement();
    break;
  default :
    assignment_statement();
  }
  debug("exit statement");
}

void parser::assignment_statement(){
  if(error_flag){return;}
  debug("enter assignment_statement");
  int tt1 = destination();
  //  cout << "t1 : " << tt1 << endl;
  check_token_type(ASSIGN,":=");
  scan_next_token();
  int tt2 = expression();
  //cout << "t2 : " << tt2 << endl;
  //cout <<"(t1,t2) = (" << tt1 << " , " << tt2 << ")" << endl;
  check_types(tt1,tt2);
  //cout << "parsed assignment statement" << endl;
  debug("exit assignment_statement");
}

int parser::destination(){
  if(error_flag){return -1;}
  debug("enter destination");
  token potentialarraytok = *next_token;
  int tt = identifier();
  if(next_token->get_type() == LBRACKET){ //array
    if(!st->is_array(potentialarraytok)){
      report_error("Indexing a non-array: " + potentialarraytok.get_value() + " is not an array.",l->get_linenumber());
    }
    scan_next_token();
    expression();
    check_token_type(RBRACKET,"]");
    scan_next_token();
  }
  //cout << "parsed destination" << endl;
  debug("exit destination; tt is " , tt);
  //  cout << "tt is" << tt << endl;
  return tt;
}
void parser::if_statement(){
  if(error_flag){return;}
  debug("enter if_statement");

  check_token_type(IF,"'if'");
  scan_next_token();
    
  expression();
    
  check_token_type(THEN,"'then'");
  scan_next_token();
  
  do{
    statement();
      
    check_token_type(SEMICOLON,"';'");
    reset_error();
    scan_next_token();
  }while(next_token->get_type()!=ELSE && next_token->get_type()!=END && next_token->get_type()!=EOFMARKER  );
    

  if(next_token->get_type() == ELSE){
    scan_next_token();
    
    do{
      statement();
      
      check_token_type(SEMICOLON,"';'");
      reset_error();
      scan_next_token();
    }while(next_token->get_type()!=END && next_token->get_type()!=EOFMARKER );
  }
  
  check_token_type(END,"'end'");
  scan_next_token();
  
  check_token_type(IF,"'if'");
  scan_next_token();
  debug("exit if_statement");
}
void parser::while_statement(){
  if(error_flag){return;}
  debug("enter while_statement");
  check_token_type(WHILE,"'while'");
  scan_next_token();
  
  expression();
  
  while(next_token->get_type()!=END && !error_flag && next_token->get_type()!=EOFMARKER){
    statement();
    
    check_token_type(SEMICOLON,"';'");
    reset_error();
    scan_next_token();
  }
  
  check_token_type(END,"'end'");
  scan_next_token();

  check_token_type(WHILE,"'while'");
  scan_next_token();
  debug("exit while_statement");
}

void parser::case_statement(){
  if(error_flag){return;}
  debug("enter case_statement");
  check_token_type(CASE,"'case'");
  scan_next_token();

  expression();
  
  check_token_type(IS,"'is'");
  scan_next_token();

  do{
    check_token_type(WHEN,"'when'");
    scan_next_token();
    
    check_token_type(NUMBER,"number");
    scan_next_token();
    
    check_token_type(THEN,"'then'");
    scan_next_token();
    
    do{
      statement();
      
      check_token_type(SEMICOLON,"';'");
      reset_error();
      scan_next_token();
    }while(next_token->get_type()!=WHEN &&next_token->get_type()!=DEFAULT && next_token->get_type()!=END && next_token->get_type()!=EOFMARKER);
  }while(next_token->get_type()!=DEFAULT && next_token->get_type()!=END && next_token->get_type()!=EOFMARKER);
  
  if(next_token->get_type()==DEFAULT){
    check_token_type(DEFAULT,"'default'");
    scan_next_token();

    check_token_type(THEN,"'then'");
    scan_next_token();
    while(next_token->get_type()!=END && !is_error() && next_token->get_type()!=EOFMARKER){
      statement();
      check_token_type(SEMICOLON,"';'");
      reset_error();
      scan_next_token();
    }
  }
  check_token_type(END,"'end'");
  scan_next_token();
  
  check_token_type(CASE,"'case'");
  scan_next_token();
  debug("exit case_statement");
}
int parser::identifier(){
  return identifier(-1);
}
int parser::identifier(int typemark){
  if(error_flag){return -1;}
  debug("enter identifier");
  check_token_type(ID,"identifier");
  //cout << *next_token << endl;
  if(typemark >=0){
    st->set_tokentype(*next_token,typemark);
  }
  int tt = st->get_tokentype(*next_token);
  if( tt < 0){
    report_error("Undeclared function or variable: " + next_token->get_value(), l->get_linenumber());
    panic();
    error_flag = true;
  }
  scan_next_token();
  debug("exit identifier; tt is " , tt);
  return tt;
}
int parser::expression(){
  if(error_flag){return -1;}
  debug("enter expression");
  int tt;
  //cout << "expression(); token: " << *next_token << endl;
  if(next_token->get_type() == NOT){
    tt = BOOLEANTYPE;
    scan_next_token();
  }
  tt = arithOp();
  int tt2 = expression2();
  if(tt2>=0)
    check_types(tt,tt2);
  //cout << "parsed expression" << endl;
  debug("exit expression; tt is " , tt);
  return tt;
}
int parser::expression2(){
  if(error_flag){return -1;}
  debug("enter expression2");
  int tt = -1, tt2=-1;
  //cout << "expression2(); token: " << *next_token << endl;
  switch(next_token->get_type()){
  case AND:
    scan_next_token();
    tt = arithOp();
    tt2 = expression2();
  case OR:
    scan_next_token();
    tt = arithOp();
    tt2 = expression2();
  }
  if(tt2 >= 0){
    check_types(tt,tt2);
  }
  //cout << "parsed expression2" << endl;
  debug("exit expression2; tt is " , tt);
  return tt;
}
int parser::arithOp(){
  if(error_flag){return -1;}
  debug("enter arithOp");
  int tt =-1, tt2 = -1;
  //cout << "arithOp(); token: " << *next_token << endl;
  tt = relation();
  tt2 = arithOp2();
  if(tt2 >=0)
    check_types(tt,tt2);
  //cout << "parsed arithOp" << endl;
  debug("exit arithOp; tt is " , tt);
  return tt;
}
int parser::arithOp2(){
  if(error_flag){return -1;}
  debug("enter arithOp2");
  int tt = -1, tt2=-1;
  switch(next_token->get_type()){
  case ADD:
    scan_next_token();
    tt = relation();
    tt2 = arithOp2();
    break;
  case SUB:
    scan_next_token();
    tt = relation();
    tt2 = arithOp2();
    break;
  case BITAND:
    scan_next_token();
    tt = relation();
    tt2 = arithOp2();
    break;
  case BITOR:
    scan_next_token();
    tt = relation();
    tt2 = arithOp2();
    break;
  }
  if(tt2>=0){
    check_types(tt,tt2);
  }
  //cout << "parsed arithOp2" << endl;
  debug("exit arithOp2; tt is " , tt);
  return tt;
}
int parser::relation(){
  if(error_flag){return -1;}
  debug("enter relation");
  int tt = -1, tt2 = -1;
  //cout << "relation(); token: " << *next_token << endl;
  tt = term();
  //  cout <<"tt after term is " << tt << endl;
  tt2 = relation2();
  if(tt2>=0)
    check_types(tt,tt2);
  //cout << "parsed relation" << endl;
  debug("exit relation; tt is " , tt);
  return tt;
}
int parser::relation2(){
  if(error_flag){return -1;}
  debug("enter relation2");
  int tt=-1, tt2=-1;
  //cout << "relation2(); token: " << *next_token << endl;
  if(next_token->get_type()==RELOP){
    scan_next_token();
    tt = term();
    tt2 = relation2();
  }  
  if(tt2 >= 0){
    check_types(tt,tt2);
  }
  //cout << "parsed relation2" << endl;
  debug("exit relation2; tt is " , tt);
  return tt;
}
int parser::term(){
  if(error_flag){return -1;}
  debug("enter term");
  int tt = -1, tt2=-1;
  //cout << "term(); token: " << *next_token << endl;
  tt = factor();
  if(next_token->get_type()==TIMES || next_token->get_type()==DIVIDE){
    scan_next_token();
    tt2 = term();
  }
  if(tt2 >=0){
    check_types(tt,tt2);
  }
  //cout << "parsed term" << endl;
  debug("exit term; tt is " , tt);
  return tt;
}
int parser::factor(){
  if(error_flag){return -1;}
  debug("enter factor");
  int tt = -1;
  token ftoken = *next_token;
  //cout << "factor(); token: " << *next_token << endl;
  switch(next_token->get_type()){
  case LPAREN:
    scan_next_token();
    tt = expression();

    check_token_type(RPAREN,"')'");
    scan_next_token();

    break;
  case ID:
    tt =identifier();
    name_or_function_call(ftoken);
    break;
  case NUMBER:
    tt = INTEGERTYPE;
    scan_next_token();
    break;
  case STRING:
    tt=STRINGTYPE;
    scan_next_token();
  }
  //cout << "parsed factor" << endl;
  debug("exit factor; tt is " , tt);
  return tt;
}

void parser::name_or_function_call(token t){
  if(error_flag){return;}
  debug("enter name_or_function_call");
  switch(next_token->get_type()){
  case LBRACKET: //array
    scan_next_token();
    expression();
    check_token_type(RBRACKET,"']'");
    scan_next_token();
    break;
  case LPAREN: // function
    if(!st->is_function(t)){
      panic();
      error_flag = true;
      return;
    }
    scan_next_token();
    if(next_token->get_type() == RPAREN){
      scan_next_token();
      break;
    }
    argument_list(t,0);
    check_token_type(RPAREN,"')'");
    scan_next_token();
  }
  //cout << "parsed name_or_function_call" << endl;
  debug("exit name_or_function_call");
}
void parser::argument_list(token t, int argnum){
  if(error_flag){return;}
  debug("enter argument_list");
  vector<int> plist = *(st->get_parameterlist(t));
  map<int, pair<int, int> > arrayparams = *(st->get_arrayparams(t));
  //cout << *st->find_entry(t)<<endl;
  //  cout << "plist size: " << plist.size() << endl;
  if(plist.size() > 0){
    token ptok = *next_token;
    int tt1 = expression();
    int tt2 =  plist[argnum];
    if(tt2 == ARRAYTYPE){
      tt2 = arrayparams[argnum].first;
      check_array_sizes(arrayparams[argnum].second,st->get_arraysize(ptok));
    }
    check_types(tt1,tt2);
    
    if(next_token->get_type() == COMMA){
      scan_next_token();
      argument_list(t,++argnum);
    }
  }
  //cout << "parsed argument list" << endl;
  debug("exit argument_list");
}

void parser::add_scope(){
  symboltable * new_st = new symboltable();
  new_st->set_prev(st);
  st = new_st;
  s->set_st(st); //sync scanner st
  //cout << "added scope; new st is " << st << endl;
}
void parser::remove_scope(){
  //  cout << "removing scope. removing st: " << st << endl;
  symboltable* old_st = st;
  st = old_st->get_prev();
  s->set_st(st);//sync scanner st
  delete(old_st);
  //  cout << "removed scope; back to " << st << endl;
}
