#include <stdio.h>
#include <math.h>
#include <string.h>
#include "code_defs.h"
#include "std_defs.h"

int getBool();
int getInt();
int getString();
int putBool(int b);
int putInt(int n);
int putString(int straddr);
int isqrt(int n);
int int2bool(int n);
int bool2int(int b);
