#include "code_defs.h"
#include "std_defs.h"
#include "runtime.h"
int main(){
goto L1;
L0: R[1] = R[1] + 2; // allocate space for array a
R[1] = R[1] + 1; //allocate space for vartmp
goto L3;
L2: R[1] = R[1] + 1; //allocate space for arg x
R[1] = R[1] + 1; //allocate space for arg y
R[1] = R[1] + 1; //allocate space for varcat
R[4] = MM[R[0] + 2];//factor x
R[5] = 1; //factor 1
R[4] = R[4] + R[5]; //arithop 2
MM[R[0] + 2] = R[4]; //assignment_statement x
R[4] = MM[R[0] + 3];//factor y
R[5] = 1; //factor 1
R[4] = R[4] + R[5]; //arithop 2
MM[R[0] + 3] = R[4]; //assignment_statement y
R[4] = 0; //factor 0
MM[R[0]] = R[4]; //assignment_statement foo
R[2] = MM[R[0]+1];
goto *R[2]; //write return statement
L3: R[3] = 0; //factor 0
R[5] = 5; //factor 5
R[4] = R[0] + R[3]; // calc array offset1
MM[R[4] + 2] = R[5]; //assignment_statement a
R[3] = 1; //factor 1
R[6] = 200; //factor 200
R[5] = R[0] + R[3]; // calc array offset1
MM[R[5] + 2] = R[6]; //assignment_statement a
R[8] = 1; //factor 1
R[9] = R[0] + R[8]; // calc array offset2
R[7] = MM[R[9] + 2]; // array factor a
MM[R[1]] = R[0]; //store old frame ptr
R[1] = R[1] + 1; //incrementing frm ptr storage 
R[0] = R[1]; //set frame ptr to top of stk
MM[R[0]] = &&PUTINT; //store addrs as func id
MM[R[0] + 1] = &&L4;
R[1] = R[1] + 2; //leave room for return value and address
MM[R[0] + 2] = R[7]; //passing argument 
goto PUTINT;
L4: R[6] = MM[R[0]]; //store return val
R[1] = R[0];
R[0] = MM[R[0]-1];
MM[R[0] + 4] = R[6]; //assignment_statement tmp
R[3] = 1; //factor 1
R[9] = 0; //factor 0
R[10] = R[0] + R[9]; // calc array offset2
R[8] = MM[R[10] + 2]; // array factor a
R[10] = 0; //factor 0
R[11] = R[0] + R[10]; // calc array offset2
R[9] = MM[R[11] + 2]; // array factor a
MM[R[1]] = R[0]; //store old frame ptr
R[1] = R[1] + 1; //incrementing frm ptr storage 
R[0] = R[1]; //set frame ptr to top of stk
MM[R[0]] = &&L2; //store addrs as func id
MM[R[0] + 1] = &&L5;
R[1] = R[1] + 2; //leave room for return value and address
MM[R[0] + 2] = R[8]; //passing argument x
MM[R[0] + 3] = R[9]; //passing argument y
goto L2;
L5: R[7] = MM[R[0]]; //store return val
R[1] = R[0];
R[0] = MM[R[0]-1];
R[6] = R[0] + R[3]; // calc array offset1
MM[R[6] + 2] = R[7]; //assignment_statement a
R[9] = 0; //factor 0
R[10] = R[0] + R[9]; // calc array offset2
R[8] = MM[R[10] + 2]; // array factor a
MM[R[1]] = R[0]; //store old frame ptr
R[1] = R[1] + 1; //incrementing frm ptr storage 
R[0] = R[1]; //set frame ptr to top of stk
MM[R[0]] = &&PUTINT; //store addrs as func id
MM[R[0] + 1] = &&L6;
R[1] = R[1] + 2; //leave room for return value and address
MM[R[0] + 2] = R[8]; //passing argument 
goto PUTINT;
L6: R[7] = MM[R[0]]; //store return val
R[1] = R[0];
R[0] = MM[R[0]-1];
MM[R[0] + 4] = R[7]; //assignment_statement tmp
R[9] = 1; //factor 1
R[10] = R[0] + R[9]; // calc array offset2
R[8] = MM[R[10] + 2]; // array factor a
MM[R[1]] = R[0]; //store old frame ptr
R[1] = R[1] + 1; //incrementing frm ptr storage 
R[0] = R[1]; //set frame ptr to top of stk
MM[R[0]] = &&PUTINT; //store addrs as func id
MM[R[0] + 1] = &&L7;
R[1] = R[1] + 2; //leave room for return value and address
MM[R[0] + 2] = R[8]; //passing argument 
goto PUTINT;
L7: R[7] = MM[R[0]]; //store return val
R[1] = R[0];
R[0] = MM[R[0]-1];
MM[R[0] + 4] = R[7]; //assignment_statement tmp
R[7] = 1; //factor 1
R[8] = 1200; //factor 1200
R[7] = R[7] != R[8]; //relation 
MM[R[0]] = R[7]; //assignment_statement test
R[2] = MM[R[0]+1];
goto *R[2]; //write return statement
L1: R[0] = 0;
R[1] = R[0];
MM[R[0]] = &&L0;
MM[R[0]+1] = &&end;
R[1] = R[1]+2;
goto L0;
GETBOOL: MM[R[0]] = getBool();
R[2] = MM[R[0]+1];
goto *R[2]; //write return statement
GETINT: MM[R[0]] = getInt();
R[2] = MM[R[0]+1];
goto *R[2]; //write return statement
GETSTRING: MM[R[0]] = getString();
R[2] = MM[R[0]+1];
goto *R[2]; //write return statement
PUTBOOL: MM[R[0]] = putBool(MM[R[0] + 2]);
R[2] = MM[R[0]+1];
goto *R[2]; //write return statement
PUTINT: MM[R[0]] = putInt(MM[R[0] + 2]);
R[2] = MM[R[0]+1];
goto *R[2]; //write return statement
PUTSTRING: MM[R[0]] = putString(MM[R[0] + 2]);
R[2] = MM[R[0]+1];
goto *R[2]; //write return statement
SQRT: MM[R[0]] = isqrt(MM[R[0] + 2]);
R[2] = MM[R[0]+1];
goto *R[2]; //write return statement
INT2BOOL: MM[R[0]] = int2bool(MM[R[0] + 2]);
R[2] = MM[R[0]+1];
goto *R[2]; //write return statement
BOOL2INT: MM[R[0]] = bool2int(MM[R[0] + 2]);
R[2] = MM[R[0]+1];
goto *R[2]; //write return statement
end:  return 0;
 }
