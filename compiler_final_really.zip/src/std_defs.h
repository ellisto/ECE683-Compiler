#include "code_defs.h"

int R[MAX_USED_REGISTER];
int MM[MM_SIZE];
